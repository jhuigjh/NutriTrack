package com.fit2081.Gan35090251.nutritrack

import android.content.Context
import android.content.Intent
import android.content.Intent.ACTION_SEND
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun InsightsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val userName = context.getSharedPreferences("UserDataPrefs", Context.MODE_PRIVATE)
    val current_user = userName.getString("current_user_id", null)
    val sharedPreferences = context.getSharedPreferences("UserDataPrefs", Context.MODE_PRIVATE)
    val dataString = sharedPreferences.getString(current_user, null)
    val dataList = dataString?.split(",") ?: emptyList()

    Surface(
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Insights: Food Score",
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(modifier = Modifier.padding(8.dp))

            val isMale = dataList[2] == "Male"
            val valueDis = if (isMale) dataList[5].toFloat() else dataList[6].toFloat()
            val valueVege = if (isMale) dataList[8].toFloat() else dataList[9].toFloat()
            val valueFruits = if (isMale) dataList[19].toFloat() else dataList[20].toFloat()
            val valueGrains = if (isMale) dataList[29].toFloat() else dataList[30].toFloat()
            val valueMeats = if (isMale) dataList[36].toFloat() else dataList[37].toFloat()
            val valueDairy = if (isMale) dataList[40].toFloat() else dataList[41].toFloat()
            val valueSodium = if (isMale) dataList[43].toFloat() else dataList[44].toFloat()
            val valueAlcohol = if (isMale) dataList[46].toFloat() else dataList[47].toFloat()
            val valueWater = if (isMale) dataList[49].toFloat() else dataList[50].toFloat()
            val valueSugar = if (isMale) dataList[54].toFloat() else dataList[55].toFloat()
            val valueUnsatFat = if (isMale) dataList[60].toFloat() else dataList[61].toFloat()
            val totalScore = if (isMale) dataList[3].toFloat() else dataList[4].toFloat()

            StaticSliderRow(label = "Discretionary", value = valueDis, maxValue = 10f)
            StaticSliderRow(label = "Vegetables", value = valueVege, maxValue = 5f)
            StaticSliderRow(label = "Fruits", value = valueFruits, maxValue = 5f)
            StaticSliderRow(label = "Grains & Cereals", value = valueGrains, maxValue = 5f)
            StaticSliderRow(label = "Meat & Alternatives", value = valueMeats, maxValue = 10f)
            StaticSliderRow(label = "Dairy & Alternatives", value = valueDairy, maxValue = 10f)
            StaticSliderRow(label = "Water", value = valueWater, maxValue = 5f)
            StaticSliderRow(label = "Unsaturated Fat", value = valueUnsatFat, maxValue = 5f)
            StaticSliderRow(label = "Sodium", value = valueSodium, maxValue = 10f)
            StaticSliderRow(label = "Added Sugars", value = valueSugar, maxValue = 10f)
            StaticSliderRow(label = "Alcohol", value = valueAlcohol, maxValue = 5f)

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Total Food Quality Score ${totalScore}/100.00",
                fontSize = 18.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Slider(
                value = totalScore,
                onValueChange = {},
                enabled = false,
                valueRange = 0f..100f,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = {
                    val shareText = "Total Food Quality Score: $totalScore/100.00"
                    val shareIntent = Intent(ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share text via"))
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Improve",
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Share",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
                Button(
                    onClick = { },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Improve",
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Improve my diet!",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StaticSliderRow(
    label: String,
    value: Float,
    maxValue: Float
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Text(
            text = "$label: %.2f / %.2f".format(value, maxValue),
            modifier = Modifier
                .width(200.dp),
            fontWeight = FontWeight.Bold,
        )
        Slider(
            value = value,
            onValueChange = {},
            valueRange = 0f..maxValue,
            enabled = false,
            modifier = Modifier.weight(1f)
        )
    }
}
