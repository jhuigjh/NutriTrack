import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.Gan35090251.nutritrack.Questionaire
import java.io.BufferedReader
import java.io.InputStreamReader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun loginBottomSheet() {
    var showBottomSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val data = processData(context, "data.csv")
    var selectedOption by remember { mutableStateOf("") }
    var inputNumber by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Button(
            onClick = { showBottomSheet = true },
            modifier = Modifier.fillMaxWidth().height(60.dp)
        ) {
            Text("Login", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        if (showBottomSheet) {
            ModalBottomSheet(
                modifier = Modifier.fillMaxHeight(),
                sheetState = sheetState,
                onDismissRequest = { showBottomSheet = false }
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Login", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it },
                    ) {
                        OutlinedTextField(
                            modifier = Modifier.menuAnchor().fillMaxWidth().padding(horizontal = 8.dp),
                            value = selectedOption,
                            placeholder = { Text("Select your ID") },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("My ID (Provided by your Clinician)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            colors = ExposedDropdownMenuDefaults.textFieldColors(),
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                        ) {
                            data.keys.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option, style = MaterialTheme.typography.bodyLarge) },
                                    onClick = {
                                        selectedOption = option
                                        expanded = false
                                    },
                                    contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inputNumber,
                        onValueChange = { inputNumber = it },
                        label = { Text("Phone Number") },
                        placeholder = { Text("Enter your phone number") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "This app is only for pre-registered users. Please have your ID and phone number handy before continuing.",
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            val userData = data[selectedOption]
                            if (userData != null && inputNumber == userData[0]) {
                                val sharedPreferences =  context.getSharedPreferences("UserDataPrefs", Context.MODE_PRIVATE).edit()
                                sharedPreferences.putString("current_user_id", selectedOption)
                                sharedPreferences.apply()

                                Toast.makeText(context, "Login Successful", Toast.LENGTH_LONG).show()
                                context.startActivity(Intent(context, Questionaire::class.java))
                            } else {
                                Toast.makeText(context, "Incorrect Credentials", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(60.dp)
                    ) {
                        Text("Continue", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

fun processData(context: Context, fileName: String): Map<String, List<String>> {
    val assets = context.assets
    val userDataMap = mutableMapOf<String, List<String>>()
    val sharedPreferences = context.getSharedPreferences("UserDataPrefs", Context.MODE_PRIVATE).edit()

    try {
        val inputStream = assets.open(fileName)
        val reader = BufferedReader(InputStreamReader(inputStream))
        reader.useLines { lines ->
            lines.drop(1).forEach { line ->
                val values = line.split(",").map { it.trim() }
                if (values.size > 1) {
                    val id = values[1]
                    val data = values.drop(0)

                    userDataMap[id] = data

                    // Save to SharedPreferences as a comma-separated string
                    sharedPreferences.putString(id, data.joinToString(","))
                }
            }
        }
        sharedPreferences.apply()

    } catch (e: Exception) {
        e.printStackTrace()
    }

    return userDataMap
}



