package com.fit2081.Gan35090251.nutritrack

import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.Gan35090251.nutritrack.ui.theme.NutriTrackTheme
import java.util.Calendar

class Questionaire : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NutriTrackTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    foodIntakeQuestionaire(
                        modifier = Modifier.padding(innerPadding),
                        onBackClick = {
                            startActivity(Intent(this@Questionaire, HomeScreen::class.java))
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun foodIntakeQuestionaire(modifier: Modifier = Modifier, onBackClick: () -> Unit) {
    val context = LocalContext.current
    val sharedPref = context.getSharedPreferences("Questionnaire", Context.MODE_PRIVATE)
    val savedPersona = sharedPref.getString("SelectedPersona", "") ?: ""
    val savedBiggestMealTime = sharedPref.getString("BiggestMealTime", "00:00") ?: "00:00"
    val savedSleepTime = sharedPref.getString("SleepTime", "00:00") ?: "00:00"
    val savedWakeUpTime = sharedPref.getString("WakeUpTime", "00:00") ?: "00:00"
    val biggestMealTime = remember { mutableStateOf(savedBiggestMealTime) }
    val sleepTime = remember { mutableStateOf(savedSleepTime) }
    val wakeUpTime = remember { mutableStateOf(savedWakeUpTime) }
    val foodItems = listOf(
        "Fruits", "Vegetables", "Grains", "Red Meat", "Seafood",
        "Poultry", "Fish", "Eggs", "Nuts/Seeds"
    )
    var expanded by remember { mutableStateOf(false) }
    val checkedState = remember { mutableStateListOf(*Array(foodItems.size) { index ->
        sharedPref.getBoolean(foodItems[index], false)
    }) }
    var selectedPersona by remember { mutableStateOf(savedPersona) }

        Surface(
        modifier = modifier.fillMaxSize(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
                Text(
                    "Food Intake Questionnaire",
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "Tick all the food categories you can eat",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 3
            ) {
                foodItems.forEachIndexed { index, item ->
                    Box(
                        modifier = Modifier.width(125.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = checkedState[index],
                                onCheckedChange = { checkedState[index] = it },
                            )
                            Text(
                                text = item,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Your Persona",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "People can be broadly classified into 6 different types based on their eating preferences." +
                        "Click on each button below to find out the different types, and select the type that best fits you!"
            )
            Spacer(modifier = Modifier.height(4.dp))
            PersonaSelectionScreen(listOf(
                "Health Devotee",
                "Mindful Eater",
                "Wellness Striver",
                "Balance Seeker",
                "Health Procrastinator",
                "Food Carefree"
            ))
            Spacer(modifier = Modifier.height(12.dp))
            Text("Which persona best fits you?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                TextField(
                    value = selectedPersona,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Your Persona") },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    placeholder = { Text("Select option") },
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                ) {
                    listOf(
                        "Health Devotee",
                        "Mindful Eater",
                        "Wellness Striver",
                        "Balance Seeker",
                        "Health Procrastinator",
                        "Food Carefree"
                    ).forEach { persona ->
                        DropdownMenuItem(
                            text = { Text(persona) },
                            onClick = {
                                selectedPersona = persona
                                expanded = false
                            },
                            contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("Timings", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            TimeQuestionRow("What time of day approx, do you normally eat your biggest meal?", biggestMealTime)
            TimeQuestionRow("What time of day approx, do you go to sleep at night?", sleepTime)
            TimeQuestionRow("What time of day approx, do you wake up in the morning?", wakeUpTime)
            Spacer(modifier = Modifier.height(4.dp))
            Button(onClick = {
                sharedPref.edit().apply {
                    foodItems.forEachIndexed { index, item ->
                        putBoolean(item, checkedState[index])
                    }
                    putString("SelectedPersona", selectedPersona)
                    putString("BiggestMealTime", biggestMealTime.value)
                    putString("SleepTime", sleepTime.value)
                    putString("WakeUpTime", wakeUpTime.value)
                    apply()
                    Toast.makeText(context, "Save Successful", Toast.LENGTH_LONG).show()
                }
            }) {
                Text("Save")
            }
        }
    }
}


@Composable
fun TimeQuestionRow(questionText: String, timeState: MutableState<String>) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = questionText,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
        TimePickerButton(timeState)
    }
    Spacer(modifier = Modifier.height(1.dp))
}

@Composable
fun TimePickerButton(mTime: MutableState<String>) {
    val mTimePickerDialog = TimePickerFun(mTime)

    OutlinedButton(
        onClick = { mTimePickerDialog.show() },
        colors = ButtonDefaults.outlinedButtonColors()
    ) {
        Icon(
            painter = painterResource(id = android.R.drawable.ic_menu_recent_history),
            contentDescription = "Clock Icon"
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = mTime.value)
    }
}

@Composable
fun TimePickerFun(mTime: MutableState<String>): TimePickerDialog {
    val context = LocalContext.current
    val mCalendar = Calendar.getInstance()
    val mHour = mCalendar.get(Calendar.HOUR_OF_DAY)
    val mMinute = mCalendar.get(Calendar.MINUTE)

    return TimePickerDialog(
        context,
        { _, selectedHour: Int, selectedMinute: Int ->
            mTime.value = "$selectedHour:$selectedMinute"
        }, mHour, mMinute, false
    )
}




